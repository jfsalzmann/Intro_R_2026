# ============================================================
# setup.R — run this once before the course starts.
# ============================================================

if (!require(pacman)) install.packages("pacman")

pacman::p_load(
  tidyverse, # core: dplyr, ggplot2, purrr, tidyr, readr, stringr, ...
  magrittr, # %>%, %$%, %<>% pipes
  gt, # tables
  htmltools, # html output
  DT, # interactive table view
  haven, # read_dta()/read_sav()
  readxl, # read_xlsx()
  writexl, # write_xlsx()
  scales, # percent-formatted axis breaks/labels
)
